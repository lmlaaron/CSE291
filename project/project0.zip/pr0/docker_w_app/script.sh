sudo docker build -t lmlaaron/docker_w_app .
sudo docker run lmlaaron/docker_w_app bin/echo "Hello world\n"

