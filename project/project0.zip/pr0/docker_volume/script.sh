sudo docker create --name store  lmlaaron/volume 
#sudo docker run -t -i lmlaaron/volume /bin/bash
